﻿namespace Repro.Maui;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
